package com.example.HotelBookingSystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateMyReservations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_my_reservations);
    }
}